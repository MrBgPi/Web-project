xhr = new XMLHttpRequest();

xhr.onreadystatechange = function() {
    if (xhr.readyState == 4 && xhr.status == 200) {
        parsedrecord = JSON.parse(xhr.responseText);
        parse(parsedrecord)
    }
};
xhr.open("GET", "https://data.cityofnewyork.us/resource/jb7j-dtam.json", true);
xhr.send();

const container = document.querySelector('.container');

// Get value from element
function GetValue(id) {
    let valueElement = id.value.trim().toLowerCase();
    
    return valueElement;
}

function GetUserAttribute(userItem, id) {
    let userAttribute = userItem.getAttribute(id).trim().toLowerCase();
    
    return userAttribute;
}

function parse(json) {
    let inputSex, inputCause;
    let itemSex, itemCause;

    document.querySelectorAll('.search-form input').forEach(input => {
        input.addEventListener('keyup', () => {
            if (input.id == 'sex') inputSex = GetValue(input);
            else if (input.id == 'leading_cause') inputCause =  GetValue(input);

            for (item of document.querySelectorAll('.json-item')) {
                itemSex = GetUserAttribute(item, 'data-sex');
                itemCause = GetUserAttribute(item, 'data-cause');

                ((itemSex==inputSex && inputSex != '') 
                    || (itemCause.includes(inputCause) && inputCause != '')
                    || (itemCause.includes(inputCause) && inputCause != '')
                    || (!inputSex && !inputCause)) ? item.classList.remove('hide') : item.classList.add('hide');
            }
        })
    });

    json.forEach((element, key) => {
        if (key >= 100) return;

        container.innerHTML += `
        <div class="json-item" data-sex="${element.sex}" data-cause="${element.leading_cause}">          
            <span>Leading cause: ${element.leading_cause}</span><br>
            <span>Race ethnicity: ${element.race_ethnicity}</span><br>
            <span>Sex: ${element.sex}</span><br>
            <span>Deaths: ${element.deaths}</span><br>
            <span>Year: ${element.year}</span>
        </div>
        `;
    });
}