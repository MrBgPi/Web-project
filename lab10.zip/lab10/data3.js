xhr = new XMLHttpRequest();

xhr.onreadystatechange = function() {
    if (xhr.readyState == 4 && xhr.status == 200) {
        json = JSON.parse(xhr.responseText);
        parseJSON(json);
    }
};
xhr.open("GET", "https://data.cityofnewyork.us/resource/vx8i-nprf.json", true);
xhr.send();

const container = document.querySelector('.container');

// Get value from element
function GetValue(id) {
    let valueElement = id.value.trim().toLowerCase();
    
    return valueElement;
}

function GetUserAttribute(userItem, id) {
    let userAttribute = userItem.getAttribute(id).trim().toLowerCase();
    
    return userAttribute;
}

function parseJSON(json) {
    let inputListNo, inputLastName;
    let itemListNo, itemLastName;

    document.querySelectorAll('.search-form input').forEach(input => {
        input.addEventListener('keyup', () => {
            if (input.id == 'list_no') inputListNo = GetValue(input);
            else if (input.id == 'last_name') inputLastName = GetValue(input);

            for (item of document.querySelectorAll('.json-item')) {
                itemListNo = GetUserAttribute(item, 'data-list-no');
                itemLastName = GetUserAttribute(item, 'data-last');

                ((itemListNo.includes(inputListNo) && inputListNo != '')
                    || (itemLastName.includes(inputLastName) && inputLastName != '')
                    || (!inputListNo && !inputLastName)) ? item.classList.remove('hide') : item.classList.add('hide');
            }
        })
    });

    json.forEach((element, key) => {
        if (key >= 50) return;

        container.innerHTML += `
        <div class="json-item" data-list-no="${element.list_no}" data-last="${element.last_name}">
            <span>First and last name: ${element.first_name} ${element.last_name}</span><br>
            <span>List No: ${element.list_no}</span><br>
            <span>List title description: ${element.list_title_desc}</span><br>
            <span>List agency description: ${element.list_agency_desc}</span><br>
            <span>Published date: ${element.published_date}</span>
        </div>
        `;
    });
}