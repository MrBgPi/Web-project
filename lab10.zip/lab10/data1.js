const container = document.querySelector('.container');

xhr = new XMLHttpRequest();
xhr.onreadystatechange = function() {
    if (xhr.readyState == 4 && xhr.status == 200) {
        json = JSON.parse(xhr.responseText);
        parse(json);
    } 
    
};
xhr.open("GET", "https://data.cityofnewyork.us/resource/ic3t-wcy2.json", true);
xhr.send();

// Get value from element
function GetValue(id) {
    let valueElement = id.value.trim().toLowerCase();
    
    return valueElement;
}

function GetUserAttribute(userItem, id) {
    let userAttribute = userItem.getAttribute(id).trim().toLowerCase();
    
    return userAttribute;
}
function parse(json) {
    let inputLastName, streetname;
    let itemLastName, itemstreetname;

    document.querySelectorAll('.search-form input').forEach(input => { 
        input.addEventListener('keyup', () => {
            if (input.id == 'applicant_s_last_name') inputLastName = GetValue(input);               
            else if (input.id == 'street_name') streetname = GetValue(input);
                
            for (item of document.querySelectorAll('.json-item')) {
                itemLastName = GetUserAttribute(item, 'data-applicants-last-name');
                itemstreetname = GetUserAttribute(item, 'data-street-name');

                ((itemLastName.includes(inputLastName) && inputLastName != '') 
                    || (itemstreetname.includes(streetname) && streetname != '')
                    || (!inputLastName && !streetname)) ? item.classList.remove('hide') : item.classList.add('hide');
            }
        })
    });
    

    json.forEach((element, key) => {
        if (key >= 50) return;

        container.innerHTML += `
        <div class="json-item" data-applicants-last-name="${element.applicant_s_last_name}" data-street-name="${element.street_name}">
            <span>Applicants first and last name: ${element.applicant_s_first_name} ${element.applicant_s_last_name}</span><br>
            <span>Job: ${element.job__}</span><br>
            <span>Street name: ${element.street_name}</span>           
        </div>
        `;
    });
}